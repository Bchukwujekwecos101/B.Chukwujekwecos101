use std::io;

fn main () {
	 println!("Welcome to Brian's Electricity Bill Estimator! ");

	 // User input for name
	 println!("What is your name? ");
	 let mut customer_name = String::new();
	 io::stdin().read_line(&mut customer_name).expect("Not a valid string ");

     // User input for unit consumption
	 println!("How many units did you consume? ");
	 let mut unit_consumption = String::new();
	 io::stdin().read_line(&mut unit_consumption).expect("Not a valid string ");
	 let unit_consumption:f64 = unit_consumption.trim().parse().expect("Not a valid number ");

	 let rate1 = 20.0;
	 let rate2 = 35.0;
	 let rate3 = 50.0;

	 let total_bill:f64 = unit_consumption * rate;

	 if unit_consumption <= 100.0 {
	 	println!("Dear {}", customer_name);
	 	println!("Your rate is 20");
        println!("Your total bill is {:.2}", total_bill);
	 }else  if unit_consumption >= 101.0 &&  unit_consumption <=300.0 {
	 	println!("Dear {}", customer_name);
	 	println!("Your rate is 35");
	 	println!("Your total bill is {:.2}",total_bill);

	 }else if unit_consumption >= 301.0 &&  unit_consumption <500.0{
	 	println!("Dear {}", customer_name);
	 	println!("Your rate is 50");
        println!("Your total bill is {:.2}",total_bill);

	 }else if unit_consumption > 500.0 {
	 	println!("Dear {}", customer_name);
	 	println!("Your rate is 50");
	 	println!("Your total bill is {:.2} + 5000.0}")
	 }

	 


}